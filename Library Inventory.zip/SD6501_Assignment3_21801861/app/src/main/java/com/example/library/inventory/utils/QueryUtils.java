package com.example.library.inventory.utils;

import android.text.TextUtils;
import android.util.Log;

import com.example.library.inventory.Extra.Book;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class QueryUtils {

    private static final String LOG_TAG = QueryUtils.class.getSimpleName();

    private QueryUtils() {
    }

    public static List<Book> fetchBookData(String requestUrl) {

        URL url = createUrl(requestUrl);

        String jsonResponse = null;
        try {
            jsonResponse = makeHttpRequest(url);
        } catch (IOException e) {
            Log.e(LOG_TAG, "Problem making the HTTP request.", e);
        }

        List<Book> books = extractFeatureFromJSON(jsonResponse);

        return books;
    }

    private static URL createUrl(String stringUrl) {
        URL url = null;
        try {
            url = new URL(stringUrl);
        } catch (MalformedURLException e) {
            Log.e(LOG_TAG, "Problem building the URL.", e);
        }
        return url;
    }

    private static String makeHttpRequest(URL url) throws IOException {
        String jsonResponse = "";

        if (url == null) {
            return jsonResponse;
        }

        HttpURLConnection urlConnection = null;
        InputStream inputStream = null;
        try {
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setReadTimeout(Constants.READ_TIMEOUT /* milliseconds */);
            urlConnection.setConnectTimeout(Constants.CONNECT_TIMEOUT /* milliseconds */);
            urlConnection.setRequestMethod(Constants.REQUEST_METHOD_GET);
            urlConnection.connect();

            if (urlConnection.getResponseCode() == Constants.SUCCESS_RESPONSE_CODE) {
                inputStream = urlConnection.getInputStream();
                jsonResponse = readFromStream(inputStream);
            } else {
                Log.e(LOG_TAG, "Error response code: " + urlConnection.getResponseCode());
            }
        } catch (IOException e) {
            Log.e(LOG_TAG, "Problem retrieving the book JSON results.", e);
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (inputStream != null) {

                inputStream.close();
            }
        }
        return jsonResponse;
    }

    private static String readFromStream(InputStream inputStream) throws IOException {
        StringBuilder output = new StringBuilder();
        if (inputStream != null) {
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream,
                    Charset.forName("UTF-8"));
            BufferedReader reader = new BufferedReader(inputStreamReader);
            String line = reader.readLine();
            while (line != null) {
                output.append(line);
                line = reader.readLine();
            }
        }
        return output.toString();
    }

    private static List<Book> extractFeatureFromJSON(String bookJSON) {

        if (TextUtils.isEmpty(bookJSON)) {
            return null;
        }

        List<Book> bookList = new ArrayList<>();

        try {

            JSONObject baseJsonResponse = new JSONObject(bookJSON);
            if (baseJsonResponse.has(Constants.JSON_KEY_ITEMS)) {
                JSONArray bookArray = baseJsonResponse.getJSONArray(Constants.JSON_KEY_ITEMS);
                JSONObject firstItemObject = bookArray.getJSONObject(0);
                JSONObject volumeInfoObject = firstItemObject.getJSONObject(Constants.JSON_KEY_VOLUME_INFO);
                String title = volumeInfoObject.getString(Constants.JSON_KEY_TITLE);
                JSONArray authorsArray = volumeInfoObject.getJSONArray(Constants.JSON_KEY_AUTHORS);
                String author = null;
                if (authorsArray.length() != 0) {
                    author = authorsArray.getString(0);
                }
                JSONArray industryIdentifiersArray =
                        volumeInfoObject.getJSONArray(Constants.JSON_KEY_INDUSTRY_IDENTIFIERS);
                String isbn = null;
                if (industryIdentifiersArray.length() != 0) {
                    for (int i = 0; i < industryIdentifiersArray.length(); i++) {
                        JSONObject currentObject = industryIdentifiersArray.getJSONObject(i);
                        if (currentObject.has(Constants.JSON_KEY_TYPE)) {
                            String isbnType = currentObject.getString(Constants.JSON_KEY_TYPE);
                            if (isbnType.equals(Constants.JSON_KEY_ISBN_13)) {
                                isbn = currentObject.getString(Constants.JSON_KEY_IDENTIFIER);
                            }
                        }
                    }
                }

                String publisher = null;
                if (volumeInfoObject.has(Constants.JSON_KEY_PUBLISHER)) {
                    publisher = volumeInfoObject.getString(Constants.JSON_KEY_PUBLISHER);
                }
                Book book = new Book(title, author, isbn, publisher);
                bookList.add(book);
            }
        } catch (JSONException e) {
            Log.e(LOG_TAG, "Problem parsing the book JSON results", e);
        }
        return bookList;
    }
}
