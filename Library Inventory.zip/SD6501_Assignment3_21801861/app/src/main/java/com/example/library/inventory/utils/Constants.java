package com.example.library.inventory.utils;

public class Constants {

    private Constants() {
    }


    static final String JSON_KEY_ITEMS = "items";
    static final String JSON_KEY_VOLUME_INFO = "volumeInfo";
    static final String JSON_KEY_TITLE = "title";
    static final String JSON_KEY_AUTHORS = "authors";
    static final String JSON_KEY_INDUSTRY_IDENTIFIERS = "industryIdentifiers";
    static final String JSON_KEY_TYPE = "type";
    static final String JSON_KEY_ISBN_13 = "ISBN_13";
    static final String JSON_KEY_IDENTIFIER = "identifier";
    static final String JSON_KEY_PUBLISHER = "publisher";

    static final int READ_TIMEOUT = 10000;

    static final int CONNECT_TIMEOUT = 15000;

    static final int SUCCESS_RESPONSE_CODE = 200;

    static final String REQUEST_METHOD_GET = "GET";

    public static final String BOOK_REQUEST_URL = "https://www.googleapis.com/books/v1/volumes?";

    public static final int DEFAULT_NUMBER = 0;
}
