package com.example.library.inventory.activity;

import android.app.AlertDialog;
import android.app.LoaderManager;
import android.content.ContentValues;
import android.content.CursorLoader;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.example.library.inventory.Extra.ProductCursorAdapter;
import com.example.library.inventory.Extra.EmptyRecyclerView;
import com.example.library.inventory.R;
import com.example.library.inventory.data.ProductContract.ProductEntry;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor>{


    private static final int PRODUCT_LOADER = 0;


    private ProductCursorAdapter mCursorAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EmptyRecyclerView recyclerView = findViewById(R.id.recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setHasFixedSize(true);


        recyclerView.setLayoutManager(layoutManager);

        RelativeLayout mEmptyLayout = findViewById(R.id.empty_view);
        recyclerView.setEmptyLayout(mEmptyLayout);

        mCursorAdapter = new ProductCursorAdapter(this);

        recyclerView.setAdapter(mCursorAdapter);

        getLoaderManager().initLoader(PRODUCT_LOADER, null, this);
    }

    private void insertDummyProduct() {

        ContentValues values = new ContentValues();
        values.put(ProductEntry.COLUMN_PRODUCT_NAME, "Life Amazing Secret");
        values.put(ProductEntry.COLUMN_PRODUCT_AUTHOR, "Gaur gopal Das");
        values.put(ProductEntry.COLUMN_PRODUCT_PUBLISHER, "India");
        values.put(ProductEntry.COLUMN_PRODUCT_ISBN, "978050212451");
        values.put(ProductEntry.COLUMN_PRODUCT_PRICE, 5);
        values.put(ProductEntry.COLUMN_PRODUCT_QUANTITY, 1);
        values.put(ProductEntry.COLUMN_SUPPLIER_NAME, "India");
        values.put(ProductEntry.COLUMN_SUPPLIER_EMAIL, "@gmail.com");
        values.put(ProductEntry.COLUMN_SUPPLIER_PHONE, "000000000");

        Uri newUri = getContentResolver().insert(ProductEntry.CONTENT_URI, values);
    }

    private void deleteAllProducts() {
        int rowsDeleted = getContentResolver().delete(ProductEntry.CONTENT_URI,
                null, null);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_catalog, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case R.id.action_insert_dummy_data:
                insertDummyProduct();
                return true;

            case R.id.action_delete_all_entries:

                showDeleteConfirmationDialog();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {

        String[] projection = {
                ProductEntry._ID,
                ProductEntry.COLUMN_PRODUCT_NAME,
                ProductEntry.COLUMN_PRODUCT_AUTHOR,
                ProductEntry.COLUMN_PRODUCT_PRICE,
                ProductEntry.COLUMN_PRODUCT_QUANTITY,
                ProductEntry.COLUMN_PRODUCT_IMAGE};

        return new CursorLoader(this,
                ProductEntry.CONTENT_URI,
                projection,
                null,
                null,
                null);
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {

        mCursorAdapter.swapCursor(data);
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

        mCursorAdapter.swapCursor(null);
    }

    private void showDeleteConfirmationDialog() {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.delete_all_dialog_msg);
        builder.setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int id) {
                // User clicked the "Delete" button, so delete all products.
                deleteAllProducts();
            }
        });

        builder.setNegativeButton(R.string.cancel, null);


        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    public void showIsbnDialog(View v) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.add_by_isbn_dialog_msg);


        LayoutInflater inflater = this.getLayoutInflater();

        builder.setView(inflater.inflate(R.layout.dialog_isbn, null));

        builder.setPositiveButton(R.string.enter_an_isbn, null);
        builder.setNegativeButton(R.string.add_manually, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                Intent intent = new Intent(MainActivity.this, EditorActivity.class);

                startActivity(intent);
            }
        });

        final AlertDialog alertDialog = builder.create();

        alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(final DialogInterface dialogInterface) {

                final EditText isbnEditText = alertDialog.findViewById(R.id.edit_dialog_isbn);

                Button button = alertDialog.getButton(AlertDialog.BUTTON_POSITIVE);
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        String isbnStringDialog = isbnEditText.getText().toString().trim();

                        if (isbnStringDialog.length() == 13) {

                            Intent intent = new Intent(MainActivity.this, IsbnActivity.class);

                            intent.putExtra(getString(R.string.isbn_in_a_dialog), isbnStringDialog);

                            startActivity(intent);
                            dialogInterface.dismiss();
                        } else {
                            Toast.makeText(MainActivity.this, getString(R.string.enter_13_digit_isbn),
                                    Toast.LENGTH_SHORT).show();
                        }
                    }

                });

            }
        });


        alertDialog.show();
    }
}
