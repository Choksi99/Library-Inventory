package com.example.library.inventory.activity;

import android.app.LoaderManager;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.example.library.inventory.Extra.Book;
import com.example.library.inventory.Extra.BookLoader;
import com.example.library.inventory.R;
import com.example.library.inventory.utils.Constants;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;


public class IsbnActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<Book>> {

    private static final int BOOK_LOADER_ID = 1;

    @BindView(R.id.empty_isbn_view) TextView mEmptyTextView;

    @BindView(R.id.loading_indicator) View mLoadingIndicator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_isbn);

        ButterKnife.bind(this);

        initializeLoader(isConnected());

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    @Override
    public Loader<List<Book>> onCreateLoader(int i, Bundle bundle) {

        Uri baseUri = Uri.parse(Constants.BOOK_REQUEST_URL);

        Uri.Builder uriBuilder = baseUri.buildUpon();

        Intent intent = getIntent();

        String isbnStringFromDialog = intent.getStringExtra(getString(R.string.isbn_in_a_dialog));

        isbnStringFromDialog = getString(R.string.query_isbn) + isbnStringFromDialog;

        uriBuilder.appendQueryParameter(getString(R.string.q), isbnStringFromDialog);

        return new BookLoader(this,  uriBuilder.toString());
    }

    @Override
    public void onLoadFinished(Loader<List<Book>> loader, List<Book> booksData) {
        mLoadingIndicator.setVisibility(View.GONE);

        if (booksData != null && !booksData.isEmpty()) {
            Book book = booksData.get(0);
            String title = book.getBookTitle();
            String author = book.getAuthor();
            String isbn = book.getIsbn();
            String publisher = book.getPublisher();


            Intent intent = new Intent(this, EditorActivity.class);

            intent.putExtra(getString(R.string.title), title);
            intent.putExtra(getString(R.string.author), author);
            intent.putExtra(getString(R.string.isbn), isbn);
            intent.putExtra(getString(R.string.publisher), publisher);
            startActivity(intent);
        } else {
            mEmptyTextView.setText(getString(R.string.no_matches_found));
            mEmptyTextView.setTextColor(getResources().getColor(R.color.color_no_matches_found_text));
        }
    }

    @Override
    public void onLoaderReset(Loader<List<Book>> loader) {

    }
    private boolean isConnected() {
        ConnectivityManager connectivityManager =
                (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        return (networkInfo != null && networkInfo.isConnected());
    }


    private void initializeLoader(boolean isConnected) {
        if (isConnected) {
            LoaderManager loaderManager = this.getLoaderManager();
            loaderManager.initLoader(BOOK_LOADER_ID, null, this);
        } else {

            mLoadingIndicator.setVisibility(View.GONE);

            mEmptyTextView.setText(getString(R.string.no_internet_connection));
            mEmptyTextView.setTextColor(getResources().getColor(R.color.color_grey_text));
            mEmptyTextView.setCompoundDrawablesWithIntrinsicBounds(Constants.DEFAULT_NUMBER,
                    R.drawable.ic_network_check,Constants.DEFAULT_NUMBER,Constants.DEFAULT_NUMBER);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
