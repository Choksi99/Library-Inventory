package com.example.library.inventory.activity;

import android.Manifest;
import android.app.AlertDialog;
import android.app.LoaderManager;
import android.content.ContentValues;
import android.content.CursorLoader;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.Loader;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.library.inventory.R;
import com.example.library.inventory.data.ProductContract.ProductEntry;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import butterknife.BindView;
import butterknife.ButterKnife;
public class DetailActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {


    private static final String LOG_TAG = DetailActivity.class.getSimpleName();

    private static final int EXISTING_PRODUCT_LOADER = 0;

    private Uri mCurrentProductUri;

    @BindView(R.id.detail_product_name) TextView mProductNameTextView;

    @BindView(R.id.detail_product_author) TextView mAuthorTextView;

    @BindView(R.id.detail_product_publisher) TextView mPublisherTextView;

    @BindView(R.id.detail_product_isbn) TextView mIsbnTextView;

    @BindView(R.id.detail_product_price) TextView mPriceTextView;

    @BindView(R.id.detail_product_quantity) TextView mQuantityTextView;

    @BindView(R.id.detail_product_image) ImageView mImageView;

    @BindView(R.id.detail_supplier_name) TextView mSupplierNameTextView;

    @BindView(R.id.detail_supplier_email) TextView mSupplierEmailTextView;

    @BindView(R.id.detail_supplier_phone) TextView mSupplierPhoneTextView;

    @BindView(R.id.detail_email_button) ImageButton mSupplierEmailButton;

    private static final int MY_PERMISSONS_REQUEST_READ_CONTACTS = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Intent intent = getIntent();
        mCurrentProductUri = intent.getData();

        ButterKnife.bind(this);

        Button plusButton = findViewById(R.id.detail_plus_button);
        Button minusButton = findViewById(R.id.detail_minus_button);
        ImageButton supplierPhoneButton = findViewById(R.id.detail_phone_button);

        plusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                increment();
            }
        });

        minusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                decrement();
            }
        });

        mSupplierEmailButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                composeEmail();
            }
        });

        supplierPhoneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                call();
            }
        });

        getLoaderManager().initLoader(EXISTING_PRODUCT_LOADER, null, this);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSONS_REQUEST_READ_CONTACTS: {

                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    Toast.makeText(this, getString(R.string.permission_granted),
                            Toast.LENGTH_SHORT).show();
                } else {

                    Toast.makeText(this, getString(R.string.permission_denied),
                            Toast.LENGTH_SHORT).show();
                }
                return;
            }

        }
    }


    private  void call() {

        String phoneString = mSupplierPhoneTextView.getText().toString().trim();

        Intent phoneIntent = new Intent(Intent.ACTION_CALL);
        phoneIntent.setData(Uri.parse(getString(R.string.tel_colon) + phoneString));

        if (ActivityCompat.checkSelfPermission(DetailActivity.this,
                Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(DetailActivity.this,
                    Manifest.permission.CALL_PHONE)) {

            } else {

                ActivityCompat.requestPermissions(DetailActivity.this,
                        new String[]{ Manifest.permission.CALL_PHONE},
                        MY_PERMISSONS_REQUEST_READ_CONTACTS);
            }
            return;
        }
        startActivity(Intent.createChooser(phoneIntent, getString(R.string.make_a_phone_call)));
    }

    private void increment() {

        String quantityString = mQuantityTextView.getText().toString().trim();


        int quantity = Integer.parseInt(quantityString);
        quantity = quantity + 1;

        ContentValues values = new ContentValues();
        values.put(ProductEntry.COLUMN_PRODUCT_QUANTITY, quantity);

        int rowsAffected = getContentResolver().update(mCurrentProductUri, values,
                null, null);
    }

    private void decrement() {

        String quantityString = mQuantityTextView.getText().toString().trim();

        int quantity = Integer.parseInt(quantityString);

        if (quantity > 0) {
            quantity = quantity - 1;
        } else if (quantity == 0) {
            Toast.makeText(DetailActivity.this, getString(R.string.detail_update_zero_quantity),
                    Toast.LENGTH_SHORT).show();
        }

        ContentValues values = new ContentValues();
        values.put(ProductEntry.COLUMN_PRODUCT_QUANTITY, quantity);

        int rowsAffected = getContentResolver().update(mCurrentProductUri, values,
                null, null);
    }

    private void composeEmail() {

        String productNameString = mProductNameTextView.getText().toString().trim();
        String authorString = mAuthorTextView.getText().toString().trim();
        String publisherString = mPublisherTextView.getText().toString().trim();
        String isbnString = mIsbnTextView.getText().toString().trim();
        String[] supplierEmailString = {mSupplierEmailTextView.getText().toString().trim()};

        String subject = getString(R.string.email_subject) + " " + productNameString;
        String message = getString(R.string.place_an_order) + " " + getString(R.string.copies_of) +
                " " + productNameString + getString(R.string.period);
        message += getString(R.string.nn) + getString(R.string.app_product_details);
        message += getString(R.string.nn) + getString(R.string.category_product_name) +
                getString(R.string.colon) + " " + productNameString;
        message += getString(R.string.n) + getString(R.string.category_product_author) +
                getString(R.string.colon) + " " + authorString;
        message += getString(R.string.n) + getString(R.string.category_product_publisher) +
                getString(R.string.colon) + " " + publisherString;
        message += getString(R.string.n) + getString(R.string.category_product_isbn) +
                getString(R.string.colon) + " "+ isbnString;
        message += getString(R.string.nn) + getString(R.string.best);

        Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
        emailIntent.setData(Uri.parse(getString(R.string.mailto)));

        emailIntent.putExtra(Intent.EXTRA_EMAIL, supplierEmailString);

        emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);

        emailIntent.putExtra(Intent.EXTRA_TEXT, message);

        if(emailIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(Intent.createChooser(emailIntent, getString(R.string.compose_email)));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_detail, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case R.id.action_edit:

                Intent intent = new Intent(DetailActivity.this, EditorActivity.class);

                intent.setData(mCurrentProductUri);

                startActivity(intent);
                return true;

            case R.id.action_delete:

                showDeleteConfirmationDialog();
                return true;

            case android.R.id.home:

                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void deleteProduct() {

        if (mCurrentProductUri != null) {

            int rowsDeleted = getContentResolver().delete(mCurrentProductUri, null,
                    null);

            if (rowsDeleted == 0) {

                Toast.makeText(this, getString(R.string.editor_delete_product_failed),
                        Toast.LENGTH_SHORT).show();
            } else {

                Toast.makeText(this, getString(R.string.editor_delete_product_successful),
                        Toast.LENGTH_SHORT).show();
            }
        }

        finish();
    }

    private void showDeleteConfirmationDialog() {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.delete_dialog_msg);
        builder.setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int id) {

                deleteProduct();
            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int id) {

                if (dialogInterface != null) {
                    dialogInterface.dismiss();
                }
            }
        });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    @Override
    public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {

        String[] projection = {
                ProductEntry._ID,
                ProductEntry.COLUMN_PRODUCT_NAME,
                ProductEntry.COLUMN_PRODUCT_AUTHOR,
                ProductEntry.COLUMN_PRODUCT_PUBLISHER,
                ProductEntry.COLUMN_PRODUCT_ISBN,
                ProductEntry.COLUMN_PRODUCT_PRICE,
                ProductEntry.COLUMN_PRODUCT_QUANTITY,
                ProductEntry.COLUMN_PRODUCT_IMAGE,
                ProductEntry.COLUMN_SUPPLIER_NAME,
                ProductEntry.COLUMN_SUPPLIER_EMAIL,
                ProductEntry.COLUMN_SUPPLIER_PHONE};


        return new CursorLoader(this,
                mCurrentProductUri,
                projection,
                null,
                null,
                null);
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {

        if (cursor == null || cursor.getCount() < 1) {
            return;
        }


        if (cursor.moveToFirst()) {

            int titleColumnIndex = cursor.getColumnIndex(ProductEntry.COLUMN_PRODUCT_NAME);
            int authorColumnIndex = cursor.getColumnIndex(ProductEntry.COLUMN_PRODUCT_AUTHOR);
            int publisherColumnIndex = cursor.getColumnIndex(ProductEntry.COLUMN_PRODUCT_PUBLISHER);
            int isbnColumnIndex = cursor.getColumnIndex(ProductEntry.COLUMN_PRODUCT_ISBN);
            int priceColumnIndex = cursor.getColumnIndex(ProductEntry.COLUMN_PRODUCT_PRICE);
            int quantityColumnIndex = cursor.getColumnIndex(ProductEntry.COLUMN_PRODUCT_QUANTITY);
            int imageColumnIndex = cursor.getColumnIndex(ProductEntry.COLUMN_PRODUCT_IMAGE);
            int supplierNameColumnIndex = cursor.getColumnIndex(ProductEntry.COLUMN_SUPPLIER_NAME);
            int supplierEmailColumnIndex = cursor.getColumnIndex(ProductEntry.COLUMN_SUPPLIER_EMAIL);
            int supplierPhoneColumnIndex = cursor.getColumnIndex(ProductEntry.COLUMN_SUPPLIER_PHONE);


            String title = cursor.getString(titleColumnIndex);
            String author = cursor.getString(authorColumnIndex);
            String publisher = cursor.getString(publisherColumnIndex);
            String isbn = cursor.getString(isbnColumnIndex);
            double price = cursor.getDouble(priceColumnIndex);
            int quantity = cursor.getInt(quantityColumnIndex);
            final String imageString = cursor.getString(imageColumnIndex);
            String supplierName = cursor.getString(supplierNameColumnIndex);
            String supplierEmail = cursor.getString(supplierEmailColumnIndex);
            String supplierPhone = cursor.getString(supplierPhoneColumnIndex);


            mProductNameTextView.setText(title);
            mAuthorTextView.setText(author);
            mPublisherTextView.setText(publisher);
            mIsbnTextView.setText(isbn);
            mPriceTextView.setText(String.valueOf(price));
            mQuantityTextView.setText(String.valueOf(quantity));

            if(imageString != null) {


                ViewTreeObserver viewTreeObserver = mImageView.getViewTreeObserver();
                viewTreeObserver.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        mImageView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                        mImageView.setImageBitmap(getBitmapFromUri(Uri.parse(imageString)));
                    }
                });
            } else {
                mImageView.setImageResource(R.drawable.ic_image_black_24dp);
            }

            mSupplierNameTextView.setText(supplierName);

            if(TextUtils.isEmpty(supplierEmail)) {
                mSupplierEmailButton.setVisibility(View.GONE);
            }
            mSupplierEmailTextView.setText(supplierEmail);
            mSupplierPhoneTextView.setText(supplierPhone);
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

        mProductNameTextView.setText("");
        mAuthorTextView.setText("");
        mPublisherTextView.setText("");
        mIsbnTextView.setText("");
        mPriceTextView.setText(String.valueOf(""));
        mQuantityTextView.setText(String.valueOf(""));
        mSupplierNameTextView.setText("");
        mSupplierEmailTextView.setText("");
        mSupplierPhoneTextView.setText("");
    }

    public Bitmap getBitmapFromUri(Uri uri) {

        if (uri == null || uri.toString().isEmpty()) {
            return null;
        }


        int targetW = mImageView.getWidth();
        int targetH = mImageView.getHeight();

        InputStream inputStream = null;
        try {
            inputStream = this.getContentResolver().openInputStream(uri);


            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(inputStream, null, bmOptions);
            inputStream.close();

            int photoW = bmOptions.outWidth;
            int photoH = bmOptions.outHeight;


            int scaleFactor = Math.min(photoW / targetW, photoH / targetH);


            bmOptions.inJustDecodeBounds = false;
            bmOptions.inSampleSize = scaleFactor;
            bmOptions.inPurgeable = true;

            inputStream = this.getContentResolver().openInputStream(uri);
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream, null, bmOptions);
            inputStream.close();
            return bitmap;

        } catch (FileNotFoundException fne) {
            Log.e(LOG_TAG, "Failed to open the image file.", fne);
            return null;
        } catch (Exception e) {
            Log.e(LOG_TAG, "Failed to load image.", e);
            return null;
        } finally {
            try {
                inputStream.close();
            } catch (IOException e) {
                Log.e(LOG_TAG, "Problem with loading a file.");
            }
        }
    }
}
