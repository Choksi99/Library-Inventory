package com.example.library.inventory.Extra;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.library.inventory.R;
import com.example.library.inventory.activity.DetailActivity;
import com.example.library.inventory.data.ProductContract.ProductEntry;

public class ProductCursorAdapter extends RecyclerView.Adapter<ProductCursorAdapter.ProductViewHolder> {


    private Cursor mCursor;
    private Context mContext;

    public ProductCursorAdapter(Context context) {
        mContext = context;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.card_item, parent, false);
        return new ProductViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder viewHolder, int position) {
        final ProductViewHolder holder = viewHolder;
        mCursor.moveToPosition(position);

        holder.setData(mCursor);

        final long id = mCursor.getLong(mCursor.getColumnIndex(ProductEntry._ID));

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(mContext, DetailActivity.class);

                Uri currentProductUri = ContentUris.withAppendedId(ProductEntry.CONTENT_URI, id);

                intent.setData(currentProductUri);

                mContext.startActivity(intent);
            }
        });

        int quantityColumnIndex = mCursor.getColumnIndex(ProductEntry.COLUMN_PRODUCT_QUANTITY);

        int quantity = mCursor.getInt(quantityColumnIndex);

        if (quantity > 0) {
            holder.saleButton.setText(mContext.getString(R.string.sell));
        } else{
            holder.saleButton.setText(mContext.getString(R.string.sold_out));
        }

        holder.saleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String quantityString = holder.quantityTextView.getText().toString().trim();

                int quantity = Integer.parseInt(quantityString);

                if (quantity > 0) {
                    holder.saleButton.setText(mContext.getString(R.string.sell));
                    quantity = quantity - 1;
                } else if (quantity == 0) {
                    holder.saleButton.setText(mContext.getString(R.string.sold_out));
                    Toast.makeText(view.getContext(),
                            view.getContext().getString(R.string.detail_update_zero_quantity),
                            Toast.LENGTH_SHORT).show();
                }

                ContentValues values = new ContentValues();
                values.put(ProductEntry.COLUMN_PRODUCT_QUANTITY, quantity);

                Uri mCurrentProductUri = ContentUris.withAppendedId(ProductEntry.CONTENT_URI, id);
                int rowsAffected = view.getContext().getContentResolver().update(mCurrentProductUri, values,
                        null, null);
            }
        });
    }

    @Override
    public int getItemCount() {
        if (mCursor == null) {
            return 0;
        }
        return mCursor.getCount();
    }

    public Cursor swapCursor(Cursor cursor) {
        if (mCursor == cursor) {
            return null;
        }
        Cursor temp = mCursor;
        this.mCursor = cursor;
        if (cursor != null) {
            this.notifyDataSetChanged();
        }
        return temp;
    }

    class ProductViewHolder extends RecyclerView.ViewHolder {

        private TextView productNameTextView;
        private TextView authorTextView;
        private TextView priceTextView;
        private TextView quantityTextView;
        private Button saleButton;
        private CardView cardView;

        ProductViewHolder(View itemView) {
            super(itemView);

            productNameTextView = itemView.findViewById(R.id.product_name_card);
            authorTextView = itemView.findViewById(R.id.product_author_card);
            priceTextView =itemView.findViewById(R.id.product_price_card);
            quantityTextView =itemView.findViewById(R.id.product_quantity_card);
            saleButton = itemView.findViewById(R.id.product_sale_button_card);
            cardView = itemView.findViewById(R.id.card_view);
        }

        public void setData(Cursor c) {
            productNameTextView.setText(c.getString(c.getColumnIndex(ProductEntry.COLUMN_PRODUCT_NAME)));
            authorTextView.setText(c.getString(c.getColumnIndex(ProductEntry.COLUMN_PRODUCT_AUTHOR)));
            priceTextView.setText(String.valueOf(c.getDouble(c.getColumnIndex(ProductEntry.COLUMN_PRODUCT_PRICE))));
            quantityTextView.setText(String.valueOf(c.getInt(c.getColumnIndex(ProductEntry.COLUMN_PRODUCT_QUANTITY))));
        }
    }
}
