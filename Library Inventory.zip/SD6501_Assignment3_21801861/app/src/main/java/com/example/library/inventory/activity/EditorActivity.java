package com.example.library.inventory.activity;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.LoaderManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.CursorLoader;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.library.inventory.R;
import com.example.library.inventory.data.ProductContract.ProductEntry;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import butterknife.BindView;
import butterknife.ButterKnife;
import pub.devrel.easypermissions.EasyPermissions;

public class EditorActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor>{


    private static final String LOG_TAG = EditorActivity.class.getSimpleName();


    private static final int EXISTING_PRODUCT_LOADER = 0;

    private static final int PICK_IMAGE_REQUEST = 1;


    private Uri mImageUri;


    private Uri mCurrentProductUri;


    @BindView(R.id.edit_product_name) EditText mProductNameEditText;


    @BindView(R.id.edit_product_author) EditText mAuthorEditText;


    @BindView(R.id.edit_product_publisher) EditText mPublisherEditText;


    @BindView(R.id.edit_product_isbn) EditText mIsbnEditText;

    @BindView(R.id.edit_product_price) EditText mPriceEditText;


    @BindView(R.id.edit_product_quantity) EditText mQuantityEditText;


    @BindView(R.id.edit_supplier_name) EditText mSupplierNameEditText;


    @BindView(R.id.edit_supplier_email) EditText mSupplierEmailEditText;


    @BindView(R.id.edit_supplier_phone) EditText mSupplierPhoneEditText;


    @BindView(R.id.edit_product_image) ImageView mImageView;

    @BindView(R.id.edit_add_image_button) Button addImageButton;


    private boolean mProductHasChanged = false;


    @BindView(R.id.layout_product_name) TextInputLayout layoutProductName;
    @BindView(R.id.layout_product_author) TextInputLayout layoutProductAuthor;
    @BindView (R.id.layout_product_isbn) TextInputLayout layoutProductIsbn;
    @BindView (R.id.layout_product_price) TextInputLayout layoutProductPrice;
    @BindView (R.id.layout_product_quantity) TextInputLayout layoutProductQuantity;
    @BindView (R.id.layout_supplier_name) TextInputLayout layoutSupplierName;
    @BindView (R.id.layout_supplier_phone) TextInputLayout layoutSupplierPhone;


    private boolean isValidate = true;


    private View.OnTouchListener mTouchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View view, MotionEvent motionEvent) {
            mProductHasChanged = true;
            return false;
        }
    };

    private String[] galleryPermissions = {Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE};

    private static final int GALLERY_PERMISSION_REQUEST_CODE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);


        ButterKnife.bind(this);


        if( getIntent().hasExtra(getString(R.string.title)) || getIntent().hasExtra(getString(R.string.author)) ||
                getIntent().hasExtra(getString(R.string.isbn)) || getIntent().hasExtra(getString(R.string.publisher)) ) {


            Intent intent = getIntent();
            String title = intent.getStringExtra(getString(R.string.title));
            mProductNameEditText.setText(title);
            String author = intent.getStringExtra(getString(R.string.author));
            mAuthorEditText.setText(author);
            String isbn = intent.getStringExtra(getString(R.string.isbn));
            mIsbnEditText.setText(isbn);
            String publisher = intent.getStringExtra(getString(R.string.publisher));
            mPublisherEditText.setText(publisher);
        }


        Intent intent = getIntent();
        mCurrentProductUri = intent.getData();


        if (mCurrentProductUri == null) {
           setTitle(R.string.editor_activity_title_new_product);

            mImageView.setImageResource(R.drawable.ic_image_black_24dp);


            invalidateOptionsMenu();
        } else {

            setTitle(R.string.editor_activity_title_edit_product);


            getLoaderManager().initLoader(EXISTING_PRODUCT_LOADER, null, this);
        }

        addImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (EasyPermissions.hasPermissions(EditorActivity.this, galleryPermissions)) {
                    pickImageFromGallery();
                } else {
                    EasyPermissions.requestPermissions(EditorActivity.this, "Access for storage",
                            GALLERY_PERMISSION_REQUEST_CODE, galleryPermissions);
                }
            }
        });


        mProductNameEditText.setOnTouchListener(mTouchListener);
        mAuthorEditText.setOnTouchListener(mTouchListener);
        mPublisherEditText.setOnTouchListener(mTouchListener);
        mIsbnEditText.setOnTouchListener(mTouchListener);
        mPriceEditText.setOnTouchListener(mTouchListener);
        mQuantityEditText.setOnTouchListener(mTouchListener);
        mSupplierNameEditText.setOnTouchListener(mTouchListener);
        mSupplierEmailEditText.setOnTouchListener(mTouchListener);
        mSupplierPhoneEditText.setOnTouchListener(mTouchListener);
        addImageButton.setOnTouchListener(mTouchListener);
        mImageView.setOnTouchListener(mTouchListener);
    }

    private void  pickImageFromGallery() {
        Intent intent;
        if (Build.VERSION.SDK_INT < 19) {

            intent = new Intent(Intent.ACTION_GET_CONTENT);
        } else {

            intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);

            intent.addCategory(Intent.CATEGORY_OPENABLE);
        }


        intent.setType(getString(R.string.image_all_format));

        startActivityForResult(Intent.createChooser(intent, getString(R.string.select_picture)), PICK_IMAGE_REQUEST);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK) {

            if (data != null) {
                mImageUri = data.getData();
                Log.i(LOG_TAG, "Uri: " + mImageUri.toString());


                mImageView.setImageBitmap(getBitmapFromUri(mImageUri));
            }
        }
    }


    public Bitmap getBitmapFromUri(Uri uri) {

        if (uri == null || uri.toString().isEmpty()) {
            return null;
        }


        int targetW = mImageView.getWidth();
        int targetH = mImageView.getHeight();

        InputStream inputStream = null;
        try {
            inputStream = this.getContentResolver().openInputStream(uri);


            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(inputStream, null, bmOptions);
            inputStream.close();

            int photoW = bmOptions.outWidth;
            int photoH = bmOptions.outHeight;


            int scaleFactor = Math.min(photoW / targetW, photoH / targetH);


            bmOptions.inJustDecodeBounds = false;
            bmOptions.inSampleSize = scaleFactor;
            bmOptions.inPurgeable = true;

            inputStream = this.getContentResolver().openInputStream(uri);
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream, null, bmOptions);
            inputStream.close();
            return bitmap;

        } catch (FileNotFoundException fne) {
            Log.e(LOG_TAG, "Failed to open the image file.", fne);
            return null;
        } catch (Exception e) {
            Log.e(LOG_TAG, "Failed to load image.", e);
            return null;
        } finally {
            try {
                inputStream.close();
            } catch (IOException e) {
                Log.e(LOG_TAG, "Problem with loading a file.");
            }
        }
    }


    private void saveProduct() {

        String productNameString = mProductNameEditText.getText().toString().trim();
        String authorString = mAuthorEditText.getText().toString().trim();
        String publisherString = mPublisherEditText.getText().toString().trim();
        String isbnString = mIsbnEditText.getText().toString().trim();
        String priceString = mPriceEditText.getText().toString().trim();
        String quantityString = mQuantityEditText.getText().toString().trim();
        String supplierNameString = mSupplierNameEditText.getText().toString().trim();
        String supplierEmailString = mSupplierEmailEditText.getText().toString().trim();
        String supplierPhoneString = mSupplierPhoneEditText.getText().toString().trim();


        ContentValues values = new ContentValues();
        values.put(ProductEntry.COLUMN_PRODUCT_NAME, productNameString);
        values.put(ProductEntry.COLUMN_PRODUCT_AUTHOR, authorString);
        values.put(ProductEntry.COLUMN_PRODUCT_PUBLISHER, publisherString);
        values.put(ProductEntry.COLUMN_PRODUCT_ISBN, isbnString);

        double price = 0.0;
        if(!TextUtils.isEmpty(priceString)) {
            price = Double.parseDouble(priceString);
        }

        int quantity = 0;
        if(!TextUtils.isEmpty(quantityString)) {
            quantity = Integer.parseInt(quantityString);
        }

        values.put(ProductEntry.COLUMN_PRODUCT_PRICE, price);
        values.put(ProductEntry.COLUMN_PRODUCT_QUANTITY, quantity);


        if (mImageUri != null) {
            values.put(ProductEntry.COLUMN_PRODUCT_IMAGE, mImageUri.toString());
            Log.e(LOG_TAG, "Uri saveProduct() : " + mImageUri.toString());
        }

        values.put(ProductEntry.COLUMN_SUPPLIER_NAME, supplierNameString);
        values.put(ProductEntry.COLUMN_SUPPLIER_EMAIL,supplierEmailString);
        values.put(ProductEntry.COLUMN_SUPPLIER_PHONE, supplierPhoneString);


        if (mCurrentProductUri == null) {

            Uri newUri = getContentResolver().insert(ProductEntry.CONTENT_URI, values);

          if (newUri == null) {

                Toast.makeText(this, getString(R.string.editor_insert_product_failed),
                        Toast.LENGTH_SHORT).show();
            } else {

                Toast.makeText(this, getString(R.string.editor_insert_product_successful),
                        Toast.LENGTH_SHORT).show();
            }
        } else {

            int rowsAffected = getContentResolver().update(mCurrentProductUri, values,
                    null, null);

            if (rowsAffected == 0) {

                Toast.makeText(this, getString(R.string.editor_update_product_failed),
                        Toast.LENGTH_SHORT).show();
            } else {

                Toast.makeText(this, getString(R.string.editor_update_product_successful),
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_editor, menu);
        return true;
    }


    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);

        if (mCurrentProductUri == null) {
            MenuItem menuItem = menu.findItem(R.id.action_delete);
            menuItem.setVisible(false);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case R.id.action_save:

                if (isValidateInput()) {

                    saveProduct();
                    NavUtils.navigateUpFromSameTask(EditorActivity.this);
                } else if (!isValidate) {

                    NavUtils.navigateUpFromSameTask(EditorActivity.this);
                }
                return true;

            case R.id.action_delete:

                showDeleteConfirmationDialog();
                return true;

            case android.R.id.home:

                if (!mProductHasChanged) {
                    NavUtils.navigateUpFromSameTask(EditorActivity.this);
                    return true;
                }


                DialogInterface.OnClickListener discardButtonClickListener =
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                // User clicked "Discard" button, navigate to parent activity
                                NavUtils.navigateUpFromSameTask(EditorActivity.this);
                            }
                        };


                showUnsavedChangesDialog(discardButtonClickListener);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onBackPressed() {

        if (!mProductHasChanged) {
            super.onBackPressed();
            NavUtils.navigateUpFromSameTask(EditorActivity.this);
            return;
        }

        DialogInterface.OnClickListener discardButtonClickListener =
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // User clicked "Discard" button, navigate to parent activity
                        NavUtils.navigateUpFromSameTask(EditorActivity.this);
                    }
                };


        showUnsavedChangesDialog(discardButtonClickListener);
    }

    @Override
    public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {

        String[] projection = {
                ProductEntry._ID,
                ProductEntry.COLUMN_PRODUCT_NAME,
                ProductEntry.COLUMN_PRODUCT_AUTHOR,
                ProductEntry.COLUMN_PRODUCT_PUBLISHER,
                ProductEntry.COLUMN_PRODUCT_ISBN,
                ProductEntry.COLUMN_PRODUCT_PRICE,
                ProductEntry.COLUMN_PRODUCT_QUANTITY,
                ProductEntry.COLUMN_PRODUCT_IMAGE,
                ProductEntry.COLUMN_SUPPLIER_NAME,
                ProductEntry.COLUMN_SUPPLIER_EMAIL,
                ProductEntry.COLUMN_SUPPLIER_PHONE};


        return new CursorLoader(this,
                mCurrentProductUri,
                projection,
                null,
                null,
                null);
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {

        if (cursor == null || cursor.getCount() < 1) {
            return;
        }

        if (cursor.moveToFirst()) {

            int titleColumnIndex = cursor.getColumnIndex(ProductEntry.COLUMN_PRODUCT_NAME);
            int authorColumnIndex = cursor.getColumnIndex(ProductEntry.COLUMN_PRODUCT_AUTHOR);
            int publisherColumnIndex = cursor.getColumnIndex(ProductEntry.COLUMN_PRODUCT_PUBLISHER);
            int isbnColumnIndex = cursor.getColumnIndex(ProductEntry.COLUMN_PRODUCT_ISBN);
            int priceColumnIndex = cursor.getColumnIndex(ProductEntry.COLUMN_PRODUCT_PRICE);
            int quantityColumnIndex = cursor.getColumnIndex(ProductEntry.COLUMN_PRODUCT_QUANTITY);
            int imageColumnIndex = cursor.getColumnIndex(ProductEntry.COLUMN_PRODUCT_IMAGE);
            int supplierNameColumnIndex = cursor.getColumnIndex(ProductEntry.COLUMN_SUPPLIER_NAME);
            int supplierEmailColumnIndex = cursor.getColumnIndex(ProductEntry.COLUMN_SUPPLIER_EMAIL);
            int supplierPhoneColumnIndex = cursor.getColumnIndex(ProductEntry.COLUMN_SUPPLIER_PHONE);


            String title = cursor.getString(titleColumnIndex);
            String author = cursor.getString(authorColumnIndex);
            String publisher = cursor.getString(publisherColumnIndex);
            String isbn = cursor.getString(isbnColumnIndex);
            double price = cursor.getDouble(priceColumnIndex);
            int quantity = cursor.getInt(quantityColumnIndex);
            final String imageString = cursor.getString(imageColumnIndex);
            String supplierName = cursor.getString(supplierNameColumnIndex);
            String supplierEmail = cursor.getString(supplierEmailColumnIndex);
            String supplierPhone = cursor.getString(supplierPhoneColumnIndex);


            mProductNameEditText.setText(title);
            mAuthorEditText.setText(author);
            mPublisherEditText.setText(publisher);
            mIsbnEditText.setText(isbn);
            mPriceEditText.setText(String.valueOf(price));
            mQuantityEditText.setText(String.valueOf(quantity));

            if(imageString != null) {


                ViewTreeObserver viewTreeObserver = mImageView.getViewTreeObserver();
                viewTreeObserver.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        mImageView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                        Log.e(LOG_TAG, "mImageUri onLoadFinished: " + mImageUri);
                        mImageUri = Uri.parse(imageString);
                        mImageView.setImageBitmap(getBitmapFromUri(mImageUri));
                    }
                });
            } else {
                mImageView.setImageResource(R.drawable.ic_image_black_24dp);
            }

            mSupplierNameEditText.setText(supplierName);
            mSupplierEmailEditText.setText(supplierEmail);
            mSupplierPhoneEditText.setText(supplierPhone);
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

        mProductNameEditText.setText("");
        mAuthorEditText.setText("");
        mPublisherEditText.setText("");
        mIsbnEditText.setText("");
        mPriceEditText.setText(String.valueOf(""));
        mQuantityEditText.setText(String.valueOf(""));
        mSupplierNameEditText.setText("");
        mSupplierEmailEditText.setText("");
        mSupplierPhoneEditText.setText("");
    }

    private void showUnsavedChangesDialog(
            DialogInterface.OnClickListener discardButtonClickListener) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.unsaved_changes_dialog_msg);
        builder.setPositiveButton(R.string.discard, discardButtonClickListener);
        builder.setNegativeButton(R.string.keep_editing, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int id) {
                if (dialogInterface != null) {
                    dialogInterface.dismiss();
                }
            }
        });


        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }


    private void showDeleteConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.delete_dialog_msg);
        builder.setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int id) {
                // User clicked the "Delete" button, so delete the product.
                deleteProduct();
            }
        });
        builder.setNegativeButton(R.string.cancel, null);
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void deleteProduct() {

        if (mCurrentProductUri != null) {

            int rowsDeleted = getContentResolver().delete(mCurrentProductUri, null,
                    null);
            if (rowsDeleted == 0) {

                Toast.makeText(this, getString(R.string.editor_delete_product_failed),
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, getString(R.string.editor_delete_product_successful),
                        Toast.LENGTH_SHORT).show();
            }
        }
        NavUtils.navigateUpFromSameTask(EditorActivity.this);
    }
    private boolean isValidateInput() {
        String productNameString = mProductNameEditText.getText().toString().trim();
        String authorString = mAuthorEditText.getText().toString().trim();
        String publisherString = mPublisherEditText.getText().toString().trim();
        String isbnString = mIsbnEditText.getText().toString().trim();
        String priceString = mPriceEditText.getText().toString().trim();
        String quantityString = mQuantityEditText.getText().toString().trim();
        String supplierNameString = mSupplierNameEditText.getText().toString().trim();
        String supplierEmailString = mSupplierEmailEditText.getText().toString().trim();
        String supplierPhoneString = mSupplierPhoneEditText.getText().toString().trim();

        if (mCurrentProductUri == null &&
                TextUtils.isEmpty(productNameString) && TextUtils.isEmpty(authorString) &&
                TextUtils.isEmpty(publisherString) && TextUtils.isEmpty(isbnString) &&
                TextUtils.isEmpty(priceString) && TextUtils.isEmpty(quantityString) &&
                TextUtils.isEmpty(supplierNameString) && TextUtils.isEmpty(supplierEmailString) &&
                TextUtils.isEmpty(supplierPhoneString) &&
                mImageUri == null) {
            isValidate = false;
            return false;
        }


        if (isValidate && TextUtils.isEmpty(productNameString)) {
            layoutProductName.setError(getString(R.string.error_product_name));
            Toast.makeText(this, getString(R.string.empty_product_name),
                    Toast.LENGTH_SHORT).show();
            return false;
        } else {
            layoutProductName.setErrorEnabled(false);
        }

        if (isValidate && TextUtils.isEmpty(authorString)) {
            layoutProductAuthor.setError(getString(R.string.error_product_author));
            Toast.makeText(this, getString(R.string.empty_product_author),
                    Toast.LENGTH_SHORT).show();
            return false;
        } else {
            layoutProductAuthor.setErrorEnabled(false);
        }

        if (isValidate && TextUtils.isEmpty(isbnString)) {
            layoutProductIsbn.setError(getString(R.string.error_product_isbn));
            hideKeyboard();
            Toast.makeText(this, getString(R.string.empty_product_isbn),
                    Toast.LENGTH_SHORT).show();
            return false;
        } else {
            layoutProductIsbn.setErrorEnabled(false);
        }

        if (isValidate && TextUtils.isEmpty(priceString)) {
            layoutProductPrice.setError(getString(R.string.error_product_price));
            Toast.makeText(this, getString(R.string.empty_product_price),
                    Toast.LENGTH_SHORT).show();
            return false;
        } else {
            layoutProductPrice.setErrorEnabled(false);
        }

        if (isValidate && TextUtils.isEmpty(quantityString)) {
            layoutProductQuantity.setError(getString(R.string.error_product_quantity));
            Toast.makeText(this, getString(R.string.empty_product_quantity),
                    Toast.LENGTH_SHORT).show();
            return false;
        } else {
            layoutProductQuantity.setErrorEnabled(false);
        }

        if (isValidate && TextUtils.isEmpty(supplierNameString)) {
            layoutSupplierName.setError(getString(R.string.error_supplier_name));
            hideKeyboard();
            Toast.makeText(this, getString(R.string.empty_supplier_name),
                    Toast.LENGTH_SHORT).show();
            return false;
        } else {
            layoutSupplierName.setErrorEnabled(false);
        }

        if (isValidate && TextUtils.isEmpty(supplierPhoneString)) {
            layoutSupplierPhone.setError(getString(R.string.error_supplier_phone));
            hideKeyboard();
            Toast.makeText(this, getString(R.string.empty_supplier_phone),
                    Toast.LENGTH_SHORT).show();
            return false;
        } else {
            layoutSupplierPhone.setErrorEnabled(false);
        }
        return true;
    }

    private void hideKeyboard() {
        View view = getCurrentFocus();
        if (view != null) {
            ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).
                    hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        }
    }
}
