Library Inventory App

Android app to help sellers manage their book inventory. Whitireia Assignment 3.

Built With

CursorAdapter, SQLite, ContentProvider, Loader, ListView.

Author
Vrajesh Choksi


(Refrence : https://github.com/mzdhr/BookStore-InventoryApp )
